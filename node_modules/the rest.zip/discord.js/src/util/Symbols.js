'use strict';

exports.MakeCacheOverrideSymbol = Symbol('djs.managers.makeCacheOverride');
